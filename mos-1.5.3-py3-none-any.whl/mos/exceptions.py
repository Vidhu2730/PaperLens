class MosError(Exception):
    """Base exception for all errors raised by the MOS SDK."""
    def __init__(self, message: str):
        super().__init__(message)


class MosAuthenticationError(MosError):
    """Raised when authentication fails (401/403) or token is invalid."""
    def __init__(self, message: str, status_code: int = None, response_body: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body        

class MosNetworkError(MosError):
    """Raised when the API is unreachable."""
    pass

class MosApiError(MosError):
    """Raised when the API returns a 400 or 500 error."""
    pass

class MosTimeoutError(MosError):
    """Raised when an operation (like polling) exceeds the specified timeout."""
    def __init__(self, message: str, timeout: int = None):
        self.timeout = timeout
        super().__init__(message)
