from importlib import metadata

# Import the classes from their internal locations
from ._sync.client import Mos
from ._async.client import AsyncMos

try:
    # This reads the version from the installed package (pyproject.toml metadata)
    __version__ = metadata.version("mos")
except metadata.PackageNotFoundError:
    # If the package isn't installed (e.g. running locally), default to unknown
    __version__ = "unknown"