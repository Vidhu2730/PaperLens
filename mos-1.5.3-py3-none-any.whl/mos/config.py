from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Auth
    cognito_domain: str = "https://product-mos-ripp.auth.us-east-1.amazoncognito.com"
    auth_scope: str = "ripp_mos/access_api"
    token_buffer_seconds: int = 60

    # MOS API
    mos_api_base: str = "https://mos.ripp.elsevier.com"


settings = Settings()
