import httpx
from typing import Optional, Dict, Any

class HTTPClient:
    def __init__(self, mos):
        self.mos = mos

        self.client = httpx.AsyncClient(
            verify=False,
            timeout=httpx.Timeout(30.0),
        )

    async def _auth_headers(self, headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """
        Merges existing headers with the Authentication header.
        Refreshes the token automatically before ensuring headers.
        """
        final_headers = headers.copy() if headers else {}

        await self.mos.auth._ensure_token()

        final_headers.setdefault(
            "Authorization",
            f"Bearer {self.mos.token}",
        )
        return final_headers

    async def post(self, url: str, **kwargs: Any) -> httpx.Response:
        user_headers = kwargs.pop("headers", None)
        headers = await self._auth_headers(user_headers)
        
        return await self.client.post(url, headers=headers, **kwargs)

    async def get(self, url: str, **kwargs: Any) -> httpx.Response:
        user_headers = kwargs.pop("headers", None)
        headers = await self._auth_headers(user_headers)
        
        return await self.client.get(url, headers=headers, **kwargs)

    async def close(self):
        await self.client.aclose()
