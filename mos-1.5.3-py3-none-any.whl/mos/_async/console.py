"""
Internal progress-output helpers for the MOS SDK.

All user-facing console output for search and evaluation flows is routed through
this module so formatting stays consistent.  Output is on by default and is not
tied to any public API surface.
"""

from __future__ import annotations

import logging
from enum import Enum
from typing import Any, Optional, Sequence

from pydantic import BaseModel

from rich import box
from rich.console import Console, Group
from rich.live import Live
from rich.logging import RichHandler
from rich.markup import escape
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    ProgressColumn,
    SpinnerColumn,
    TaskID,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

# Shared console ensures RichHandler and Progress bars coordinate output so
# log messages never overwrite the live progress display.
_console = Console(highlight=False)

# SDK-scoped logger.  Applications can configure logging.getLogger("mos") to
# adjust verbosity or redirect output.  propagate=False prevents SDK messages
# from leaking into the application root logger.
_handler = RichHandler(
    console=_console,
    rich_tracebacks=True,
    show_path=False,
    show_time=False,
    markup=False,
)
_handler.setFormatter(logging.Formatter("%(message)s"))

logger = logging.getLogger("mos")
logger.setLevel(logging.INFO)
if not logger.handlers:
    logger.addHandler(_handler)
logger.propagate = False

# log() is a convenience alias for logger.info so existing call sites that
# call log("msg") continue to work at INFO level without any changes.
log = logger.info


# ── Shared formatting helpers ──────────────────────────────────────────────────

def _enum_value(value) -> str:
    return value.value if hasattr(value, "value") else str(value)


def _gpt_model_label(gpt_model) -> str:
    """Format a GPT model enum or raw string as a human-readable label."""
    raw = _enum_value(gpt_model)
    s = raw.replace("_", "-").strip("-")
    result = []
    for token in s.split("-"):
        if token.lower() == "gpt":
            result.append(token.upper())
        elif token[:1].isdigit() or "." in token:
            result.append(token)
        else:
            result.append(token.capitalize())
    return " ".join(result)


def _truncate(text: str, length: int = 80) -> str:
    return text if len(text) <= length else text[:length] + "…"


_LABEL_ABBREVS = {"es", "id", "ids", "api", "url"}


def _humanize_value(s: str) -> str:
    parts = s.replace("_", " ").split()
    return " ".join(w.upper() if w.lower() in _LABEL_ABBREVS else w.capitalize() for w in parts)


def _render_field_value(field_name: str, value: Any) -> Any:
    """Render one model field value for Rich display.

    Dispatch order matters: bool < Enum < BaseModel < str < number.
    """
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, Enum):
        if "model" in field_name:
            return _gpt_model_label(value)
        return _humanize_value(value.name)
    if isinstance(value, list):
        if not value:
            return "—"
        return ", ".join(
            _humanize_value(item.name) if isinstance(item, Enum) else str(item)
            for item in value
        )
    if isinstance(value, BaseModel):
        return _format_config_model(value)
    if isinstance(value, str):
        if any(k in field_name for k in ("prompt", "query", "criteria")):
            return _truncate(value)
        if "model" in field_name:
            return _gpt_model_label(value)
        return _humanize_value(value)
    return str(value)


def _format_config_model(cfg: BaseModel) -> Table:
    """Generic sub-table renderer for any Pydantic config model."""
    inner = Table(show_header=False, box=None, padding=(0, 1), pad_edge=False, show_edge=False)
    inner.add_column(style="bold dim", no_wrap=True)
    inner.add_column()
    for field_name in type(cfg).model_fields:
        value = getattr(cfg, field_name)
        if value is None:
            continue
        inner.add_row(_humanize_value(field_name), _render_field_value(field_name, value))
    return inner


def log_deep_search_config(ds) -> None:
    """Log the fully-merged deep search config as a key/value table.

    Iterates DeepSearchConfig.model_fields in declaration order — new fields
    appear automatically without changes here.
    """
    rows: list[tuple[str, Any]] = []
    for field_name in type(ds).model_fields:
        cfg = getattr(ds, field_name)
        label = _humanize_value(field_name)
        rows.append((label, _format_config_model(cfg) if cfg is not None else "—"))
    log_key_value_table("Deep Search Config", rows)


# ── Key/value table ────────────────────────────────────────────────────────────

def log_key_value_table(
    title: str,
    rows: Sequence[tuple[str, Any]],
) -> None:
    """
    Print a titled two-column key/value table.

    rows is an ordered sequence of (key, value) pairs; value may be a plain
    string or any Rich renderable (e.g. a nested Table).
    """
    table = Table(
        title=title,
        show_header=False,
        box=box.ROUNDED,
        title_style="bold",
        padding=(0, 1),
    )
    table.add_column("Key", style="bold dim", no_wrap=True)
    table.add_column("Value", overflow="fold")
    for key, value in rows:
        table.add_row(escape(key), escape(str(value)) if isinstance(value, str) else value)
    _console.print(table)


# ── Generic progress bar ───────────────────────────────────────────────────────

class MosProgressBar:
    """
    Generic SDK progress bar backed by Rich.

    Two modes:
    - Percentage (deep search)  – MosProgressBar(label, total=100, unit="%")
    - Count-based (evaluation)  – MosProgressBar(label, total=N, unit="articles")

    When ``live_group=True`` the bar is rendered inside a ``rich.live.Live``
    context that owns the whole terminal region.  The progress bar is pinned at
    the top and every ``write()`` call appends a line below it.  Nothing is
    ever printed outside the live region, so the bar never "scrolls up" and
    re-appears below each message.

    ``update(current)`` sets the absolute position (not a delta).
    ``write(message)`` prints a message; in live_group mode it appears below the bar.
    ``set_status(**kwargs)`` annotates the bar with count key-value pairs.
    ``close(status)`` finalises the bar with an optional terminal status label.
    """

    def __init__(self, label: str, total: int, unit: str = "%", live_group: bool = False) -> None:
        self._label = label
        self._total = total
        self._unit = unit
        self._last = 0
        self._closed = False
        self._task_id: Optional[TaskID] = None
        self._live: Optional[Live] = None
        self._messages: list[str] = []

        # Pick the right "completion" column for the mode:
        #   "%"    → "73%"   via TaskProgressColumn
        #   other  → "73/100 articles" via MofNCompleteColumn + unit suffix
        completion_column: ProgressColumn
        if unit == "%":
            completion_column = TaskProgressColumn()
        else:
            completion_column = MofNCompleteColumn()

        columns: list[ProgressColumn] = [
            SpinnerColumn(),
            TextColumn("[bold]{task.description}"),
            BarColumn(),
            completion_column,
        ]
        if unit and unit != "%":
            columns.append(TextColumn(f"[dim]{unit}"))
        columns.extend([
            TextColumn("[dim]{task.fields[status]}"),
            TimeElapsedColumn(),
        ])

        self._progress = Progress(
            *columns,
            console=_console,
            transient=False,
            disable=not _console.is_terminal,
        )

        # Honour disable: if not a terminal, the progress is a silent no-op
        # and we must not start a Live region either (it would fight tests/CI).
        if total > 0 and _console.is_terminal:
            self._task_id = self._progress.add_task(label, total=total, status="")
            if live_group:
                self._live = Live(
                    self._render(),
                    console=_console,
                    refresh_per_second=4,
                    transient=False,
                )
                self._live.start()
            else:
                self._progress.start()

    def __enter__(self) -> "MosProgressBar":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        # Always finalise — even on exceptions — so the terminal state is restored.
        if not self._closed:
            self.close(status="error" if exc_type else None)

    def _render(self):
        """Build the live renderable: progress bar pinned at top, messages below."""
        if self._messages:
            return Group(
                self._progress,
                Rule(style="dim"),
                Text("\n\n".join(self._messages)),
            )
        return self._progress

    def update(self, current: int) -> None:
        """Advance the bar to ``current`` (absolute position, not delta)."""
        if self._total == 0 or self._task_id is None:
            return
        delta = max(0, current - self._last)
        self._last = current
        self._progress.update(self._task_id, advance=delta)
        if self._live is not None:
            self._live.update(self._render())

    def write(self, message: str) -> None:
        """Print a message; in live_group mode it appears below the bar."""
        if self._live is not None:
            self._messages.append("\u25b8 " + message.strip())
            self._live.update(self._render())
        else:
            logger.info(message)

    def set_status(self, **counts: int) -> None:
        """
        Annotate the bar with count pairs, e.g. set_status(active=5, pending=20).
        Non-zero values only are shown to keep the display concise.
        """
        if self._task_id is None:
            return
        parts = [f"{k}={v}" for k, v in counts.items() if v]
        self._progress.update(self._task_id, status=", ".join(parts))

    def close(self, status: Optional[str] = None) -> None:
        """Finalise the bar with an optional terminal status label."""
        if self._closed:
            return
        self._closed = True
        if self._task_id is not None and status:
            self._progress.update(
                self._task_id,
                description=f"{self._label} [{status}]",
            )
        if self._live is not None:
            self._live.update(self._render())
            self._live.stop()
        elif self._task_id is not None:
            # Only stop if we ever started (in disable/total<=0 modes nothing was started).
            self._progress.stop()
