import functools
import asyncio
import inspect
import threading
from typing import Any, Callable, TypeVar
import httpx
from mos.exceptions import (
    MosApiError,
    MosAuthenticationError,
    MosNetworkError,
    MosTimeoutError,
)


def handle_http_errors(func):
    """
    Decorator to catch httpx errors and map them to Mos custom exceptions.
    Handles:
    - Network Connectivity (DNS, Timeout) -> MosNetworkError
    - 401/403 (Unauthorized/Forbidden)    -> MosAuthenticationError
    - 500+ (Server Errors)                -> MosApiError
    - Other 4xx (Client Errors)           -> MosApiError
    Usage: @handle_common_errors (no parentheses)
    Note: The decorated function must call response.raise_for_status() for status errors to be caught.
    """
    def _http_status_to_mos_error(e: httpx.HTTPStatusError):
        status = e.response.status_code
        error_text = e.response.text

        if status in (401, 403):
            return MosAuthenticationError(f"Unauthorized ({status}): {error_text}")

        if status >= 500:
            return MosApiError(f"Internal server error ({status}): {error_text}")

        # Other client-side errors (e.g. 400, 404, 422)
        return MosApiError(f"API request failed ({status}): {error_text}")

    async def _await_with_errors(awaitable):
        try:
            return await awaitable

        except httpx.RequestError as e:
            # Captures DNS issues, connection timeouts, no internet
            raise MosNetworkError(f"Network error occurred: {e}") from e

        except httpx.HTTPStatusError as e:
            # Captures 4xx and 5xx errors
            raise _http_status_to_mos_error(e) from e

    async def _iterate_with_errors(aiter):
        try:
            async for item in aiter:
                yield item

        except httpx.RequestError as e:
            # Captures DNS issues, connection timeouts, no internet
            raise MosNetworkError(f"Network error occurred: {e}") from e

        except httpx.HTTPStatusError as e:
            # Captures 4xx and 5xx errors
            raise _http_status_to_mos_error(e) from e

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            result = func(*args, **kwargs)

        except httpx.RequestError as e:
            # Captures DNS issues, connection timeouts, no internet
            raise MosNetworkError(f"Network error occurred: {e}") from e

        except httpx.HTTPStatusError as e:
            # Captures 4xx and 5xx errors
            raise _http_status_to_mos_error(e) from e

        if hasattr(result, "__aiter__"):
            return _iterate_with_errors(result)

        if inspect.isawaitable(result):
            return _await_with_errors(result)

        return result

    return wrapper


def ensure_auth(func):
    """
    Decorator that ensures `self._ensure_token()` is called before the decorated method.
    Usage: @ensure_auth (no parentheses)
    """

    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        # 1. Call the auth check on the instance (self)
        await self.mos.auth._ensure_token()
        # 2. Proceed with the original async function
        return await func(self, *args, **kwargs)

    return wrapper

T = TypeVar("T")

def timeout_from_param(param_name: str):
    """
    Timeout decorator that reads timeout dynamically
    from a function argument.

    Args:
        param_name (str):
            Maximum execution time in seconds.

    Raises:
        MosTimeoutError:
            If the function execution exceeds the specified timeout.

    Usage:
        @timeout_from_param("timeout")
        async def fn(..., timeout=30):
            ...
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        sig = inspect.signature(func)
        is_async = inspect.iscoroutinefunction(func)

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> T:
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            timeout_value = bound_args.arguments.get(param_name)

            if timeout_value is None or timeout_value <= 0:
                return await func(*args, **kwargs)

            try:
                return await asyncio.wait_for(
                    func(*args, **kwargs), timeout=timeout_value
                )
            except asyncio.TimeoutError as e:
                raise MosTimeoutError(
                    message=f"Operation timed out after {timeout_value}s",
                    timeout=timeout_value,
                ) from e

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> T:
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            timeout_value = bound_args.arguments.get(param_name)

            if timeout_value is None or timeout_value <= 0:
                return func(*args, **kwargs)

            # Container for the result and exception to pass from thread
            result: list[Any] = [None]
            exception: list[Exception | None] = [None]

            def target():
                try:
                    result[0] = func(*args, **kwargs)
                except Exception as e:
                    exception[0] = e

            worker_thread = threading.Thread(target=target, daemon=True)
            worker_thread.start()
            worker_thread.join(timeout=timeout_value)

            if worker_thread.is_alive():
                raise MosTimeoutError(
                    message=f"Operation timed out after {timeout_value}s",
                    timeout=timeout_value
                )

            if exception[0]:
                raise exception[0]

            return result[0]

        # Dispatch based on the nature of the original function
        return async_wrapper if is_async else sync_wrapper

    return decorator
