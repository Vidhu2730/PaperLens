import json
from typing import List

from pydantic import ValidationError, validate_call

from mos.config import settings
from mos.enums import DefaultPromptCategory, SearchType
from mos.exceptions import MosError
from mos.models import ArticleSearch, DeepSearchEvent, ScopusArticle

from ..console import MosProgressBar, log, log_deep_search_config, logger
from ..decorators import handle_http_errors


def _truncate(text: str, length: int = 80) -> str:
    return text if len(text) <= length else text[:length] + "…"

class Search:
    def __init__(self, mos):
        self.mos = mos

    @handle_http_errors
    @validate_call
    async def articles(
        self,
        article_search: ArticleSearch,
    ) -> List[ScopusArticle]:
        """
        Retrieves scientific articles based on the provided search criteria.

        For standard search types (elastic, vector, citation, eids), this method
        executes a single POST request and returns the results directly.

        For deep_search, this method initiates an async task via POST, then
        subscribes to a Server-Sent Events (SSE) stream for real-time progress
        updates before returning the final results.

        Args:
            article_search (ArticleSearch): An object containing the search query,
                date ranges, search type, and filters to apply.
        Returns:
            List[ScopusArticle]: A list of validated article objects containing
                metadata (title, authors, abstract, etc.).

        Raises:
            MosNetworkError: If a network connection issue occurs (DNS, Timeout).
            MosAuthenticationError: If the API request is unauthorized (401/403).
            MosApiError: If the MOS server returns a client (4xx) or server (5xx) error.
            MosError: If an unexpected runtime error occurs during processing.
        """
        try:
            url = f"{settings.mos_api_base}/api/search"

            search_type_label = article_search.search_type.value
            query_display = _truncate(article_search.search_query or "")

            # Build config dict, merging default prompts for deep search
            if article_search.search_type == SearchType.DEEP_SEARCH:
                if not article_search.config or not article_search.config.deep_search:
                    raise MosError(
                        "Deep Search config is mandatory when search type is deep search"
                    )

                deep_search_prompts = await self.mos.prompts.defaults(
                    category=DefaultPromptCategory.DEEP_SEARCH
                )
                es_prompts = await self.mos.prompts.defaults(
                    category=DefaultPromptCategory.ES_SEARCH_QUERY
                )

                ds = article_search.config.deep_search

                # Inject missing prompts directly into the model
                if ds and ds.normalize and not ds.normalize.prompt:
                    ds.normalize.prompt = deep_search_prompts.normalize_query_prompt

                if ds and ds.create_variations and not ds.create_variations.prompt:
                    ds.create_variations.prompt = deep_search_prompts.topic_variations_prompt

                if ds and ds.generate_es_query and not ds.generate_es_query.prompt:
                    ds.generate_es_query.prompt = (
                        es_prompts.convert_es_search_query_prompt
                    )

                # Dump config AFTER prompt injection
                config_dict = article_search.config.model_dump(exclude_none=True)
                log_deep_search_config(ds)

            else:
                config_dict = (
                    article_search.config.model_dump(exclude_none=True)
                    if article_search.config
                    else {}
                )
            # -------------------------------
            # Request Payload
            # -------------------------------
            payload = {
                "topic": article_search.search_query,
                "page_number": 1,
                "results_per_page": article_search.number_of_results,
                "sd_documents_only": article_search.limit_to_science_direct,
                "show_empty_abstracts": article_search.show_empty_abstracts,
                "source_types": article_search.source_types,
                "citation_types": article_search.citation_types,
                "search_type": article_search.search_type,
                "year": article_search.starting_year,
                "eid": article_search.eid or "",
                "eids": str(article_search.eids) if article_search.eids else "",
                "author_ids": article_search.author_ids,
                "config": config_dict,
            }

            # ---- Standard search: single request/response ----
            if article_search.search_type != SearchType.DEEP_SEARCH:
                log(f"Search started — type={search_type_label}, query={query_display!r}")
                response = await self.mos.http.post(
                    url,
                    json=payload,
                    timeout=5 * 60,
                )
                response.raise_for_status()
                data = response.json()
                raw_article_list = data.get("data", [])
                valid_articles: List[ScopusArticle] = []
                for raw_article in raw_article_list:
                    try:
                        valid_articles.append(ScopusArticle(**raw_article))
                    except ValidationError as ve:
                        logger.warning(f"Article validation error (skipping): {ve}")
                        continue
                log(f"Search completed — {len(valid_articles)} articles retrieved")
                return valid_articles

            # ---- Deep Search: enqueue and SSE streaming flow ----
            log(f"Deep search started — query={query_display!r}")
            response = await self.mos.http.post(
                url,
                json=payload,
                timeout=5 * 60,
            )
            response.raise_for_status()
            data = response.json()

            task_id = data.get("data", {}).get("task_id")
            if not task_id:
                raise MosError("No task_id returned from deep search API.")
            log(f"Deep search task enqueued — task_id={task_id}")

            stream_url = f"{settings.mos_api_base}/api/search/deep-search/stream/{task_id}"
            articles: List[ScopusArticle] = []
            bar: MosProgressBar | None = None
            bar_label = f"Deep search [{task_id[:8]}…]"

            def _ensure_bar() -> MosProgressBar:
                nonlocal bar
                if bar is None:
                    bar = MosProgressBar(
                        label=bar_label,
                        total=100,
                        unit="%",
                        live_group=True,
                    )
                return bar

            try:
                async with self.mos.http.client.stream(
                    "GET",
                    stream_url,
                    headers=await self.mos.http._auth_headers({"Accept": "text/event-stream"}),
                    timeout=10 * 60,
                ) as stream_response:
                    stream_response.raise_for_status()
                    buffer = ""

                    async for chunk in stream_response.aiter_text():
                        buffer += chunk
                        # SSE delimits events with a blank line; process each
                        # complete event, keep any partial in buffer.
                        while "\n\n" in buffer:
                            raw_event, buffer = buffer.split("\n\n", 1)
                            data_lines = [
                                # "data: foo" or "data:foo" per the SSE spec
                                line[5:].lstrip()
                                for line in raw_event.splitlines()
                                if line.startswith("data:")
                            ]
                            if not data_lines:
                                continue
                            json_str = "\n".join(data_lines).strip()
                            if not json_str:
                                continue

                            try:
                                msg = json.loads(json_str)
                            except json.JSONDecodeError as jde:
                                logger.warning(f"JSON decode error while reading SSE stream: {jde}")
                                continue

                            try:
                                event = DeepSearchEvent(**msg)
                            except ValidationError as ve:
                                logger.warning(f"SSE event validation error (skipping): {ve}")
                                continue

                            if event.type == "started":
                                # Guard against duplicate "started" events: don't
                                # orphan an existing Live region.
                                _ensure_bar()
                                if event.message:
                                    bar.write(event.message.strip())  # type: ignore[union-attr]

                            elif event.type == "progress":
                                progress_pct = int(event.progress or 0)
                                _ensure_bar().update(progress_pct)
                                message = (event.message or "").strip()
                                if message:
                                    bar.write(message)  # type: ignore[union-attr]

                            # Incremental article append during streaming
                            elif event.append and event.payload:
                                for raw in event.payload:
                                    try:
                                        articles.append(ScopusArticle(**raw))
                                    except ValidationError as ve:
                                        logger.warning(f"Article validation error (skipping): {ve}")
                                        continue
                                progress_msg = f"{len(articles)} articles received so far"
                                if bar:
                                    bar.write(progress_msg)
                                else:
                                    log(f"Deep search — {progress_msg}")

                            elif event.type == "completed":
                                for raw in event.payload or []:
                                    try:
                                        articles.append(ScopusArticle(**raw))
                                    except ValidationError as ve:
                                        logger.warning(f"Article validation error on completed event: {ve}")
                                        continue
                                if bar:
                                    if event.message:
                                        bar.write(event.message.strip())
                                    bar.update(100)
                                    bar.close(status="completed")
                                    bar = None
                                else:
                                    log(
                                        f"Deep search completed — task_id={task_id}, "
                                        f"total articles={len(articles)}"
                                    )
                                return articles

                            elif event.type == "cancelled":
                                if bar:
                                    if event.message:
                                        bar.write(event.message.strip())
                                    bar.close(status="cancelled")
                                    bar = None
                                else:
                                    log(
                                        f"Deep search cancelled — task_id={task_id}, "
                                        f"articles collected so far={len(articles)}"
                                    )
                                return articles

                            elif event.type == "error":
                                if bar:
                                    if event.message:
                                        bar.write(event.message.strip())
                                    bar.close(status="error")
                                    bar = None
                                raise MosError(
                                    f"Deep search failed: {event.message or 'Unknown error'}"
                                )

                log(
                    f"Deep search stream ended without 'completed' event — "
                    f"task_id={task_id}, returning {len(articles)} articles"
                )
                return articles
            finally:
                # Restore terminal state if we exit without a terminal event
                # (network drop, timeout, asyncio.CancelledError).
                if bar is not None:
                    bar.close(status="stopped")

        except MosError:
            raise
        except Exception as e:
            raise MosError("Failed to fetch articles") from e
