import os
from typing import List
from pydantic import validate_call
from mos.config import settings
from mos.exceptions import MosError
from mos.enums import DefaultPromptCategory, ExtractCriteriaPromptType
from mos.models import ExtractCriteriaFromPdf, ExtractCriteriaFromSD
from ..decorators import handle_http_errors
from enum import Enum


class ExtractCriteria:
    """
    Service class responsible for extracting evaluation criteria from
    scientific documents and online resources.

    This class provides high-level asynchronous methods for extracting
    structured criteria using GPT-based models. It supports multiple
    input sources, such as uploaded PDF documents and ScienceDirect URLs,
    and automatically falls back to system-default prompts when a
    user-defined prompt is not provided.
    """

    def __init__(self, mos):
        """
        Initializes the ExtractCriteria service.

        Args:
            client: An authenticated AsyncMos client instance used to
                access authorization tokens and shared services such as
                default prompt retrieval.
        """
        self.mos = mos

    async def _resolve_prompt(
        self,
        user_prompt: str,
        prompt_type:str
    ) -> str:
        """
        Resolves which prompt should be used for extraction.

        Returns the user-supplied prompt if provided. Otherwise,
        fetches and returns the appropriate system default prompt
        based on the prompt_type.
        """
        if user_prompt:
            return user_prompt

        defaults = await self.mos.prompts.defaults(
            category=DefaultPromptCategory.EXTRACT_CRITERIA
        )

        if prompt_type == ExtractCriteriaPromptType.SYSTEMATIC_REVIEW:
            return defaults.systematic_review_prompt
        else:
            return defaults.extract_criteria_prompt

    def _serialize_form_data(self, data: dict) -> dict:
        """
        Prepare multipart/form-data payload for API requests.
            - Removes None values
            - Serializes Enum values to their `.value`
            - Casts all other values to strings
        """
        serialized_data = {}
        for key, value in data.items():
            if value is None:
                continue
            if isinstance(value, Enum):
                serialized_data[key] = value.value
            else:
                serialized_data[key] = str(value)
        return serialized_data

    @handle_http_errors
    @validate_call
    async def from_pdf(
        self, request: ExtractCriteriaFromPdf
    ) -> List[str]:
        """
        Extracts evaluation criteria from an uploaded PDF document.

        This method sends a multipart request containing the PDF file,
        a resolved extraction prompt, and GPT model configuration to
        the MOS API. The API response is parsed and returned as a list
        of extracted criteria strings.

        If the user does not provide a custom extraction prompt, the
        method automatically falls back to the system-defined default
        prompt for criteria extraction.

        Args:
            request (ExtractCriteriaFromPdf): An object containing the
                uploaded PDF file, optional extraction prompt, and GPT
                model configuration parameters.

        Returns:
            List[str]: A list of extracted evaluation criteria. Returns
                an empty list if no criteria are identified.

        Raises:
            MosNetworkError: If a network connection issue occurs
                (DNS failure, connection timeout).
            MosAuthenticationError: If the API request is unauthorized
                (HTTP 401 or 403).
            MosApiError: If the MOS server returns a client (4xx) or
                server (5xx) error.
            MosError: If an unexpected runtime error occurs during
                criteria extraction.
        """
        try:
            pdf_path = request.file_path
            file_name = os.path.basename(pdf_path)
            with open(pdf_path, "rb") as f:
                file_content = f.read()

            prompt = await self._resolve_prompt(request.prompt, request.prompt_type)
            url = f"{settings.mos_api_base}/api/v1/criteria/extract/pdf"

            files = {
                "file": (file_name, file_content, "application/pdf")
            }

            raw_data = {
                "prompt": prompt,
                "gpt_model": request.gpt_config.gpt_model.value,
                "reasoning_effort": getattr(request.gpt_config.reasoning_effort, "value", None),
                "verbosity": getattr(request.gpt_config.verbosity, "value", None),
                "temperature": request.gpt_config.temperature,
            }
            data = self._serialize_form_data(raw_data)

            response = await self.mos.http.post(
                url,
                files=files,
                data=data,
                timeout=5 * 60,
            )

            response.raise_for_status()
            return response.json().get("data", {}).get("open_research_questions", [])

        except Exception as e:
            raise MosError(
                "Failed to extract criteria from PDF"
            ) from e

    @handle_http_errors
    @validate_call
    async def from_science_direct_url(
        self, request: ExtractCriteriaFromSD
    ) -> List[str]:
        """
        Extracts evaluation criteria from a ScienceDirect article URL.

        This method submits the article URL, a resolved extraction prompt,
        and GPT model configuration to the MOS API. The response is parsed
        into a list of extracted criteria strings suitable for downstream
        evaluation workflows.

        If the user does not provide a custom extraction prompt, the
        system-default criteria extraction prompt is used automatically.

        Args:
            request (ExtractCriteriaFromSD): An object
                containing the ScienceDirect article URL, optional
                extraction prompt, and GPT model configuration.

        Returns:
            List[str]: A list of extracted evaluation criteria. Returns
                an empty list if no criteria are identified.

        Raises:
            MosNetworkError: If a network connection issue occurs
                (DNS failure, connection timeout).
            MosAuthenticationError: If the API request is unauthorized
                (HTTP 401 or 403).
            MosApiError: If the MOS server returns a client (4xx) or
                server (5xx) error.
            MosError: If an unexpected runtime error occurs during
                criteria extraction.
        """
        try:
            prompt = await self._resolve_prompt(
                request.prompt,
                request.prompt_type
            )

            url = (
                f"{settings.mos_api_base}"
                "/api/v1/criteria/extract/science-direct-url"
            )

            payload = {
                "url": request.uri,
                "prompt": prompt,
                "gpt_model": request.gpt_config.gpt_model,
                "reasoning_effort": request.gpt_config.reasoning_effort,
                "verbosity": request.gpt_config.verbosity,
                "temperature": request.gpt_config.temperature,
            }

            response = await self.mos.http.post(
                url,
                json=payload,
                timeout=5 * 60,
            )

            response.raise_for_status()
            return response.json().get("data", {}).get("open_research_questions", [])

        except Exception as e:
            raise MosError(
                "Failed to extract criteria from ScienceDirect URL"
            ) from e
