import asyncio
import time
from typing import Any, List, Optional

from pydantic import Field, validate_call

from mos.config import settings
from mos.enums import (
    DefaultPromptCategory,
    EvaluationStatus,
    EvaluationType,
)
from mos.exceptions import MosError, MosTimeoutError
from mos.models import (
    EvaluationHistory,
    EvaluationHistoryApiResponse,
    EvaluationRequest,
    EvaluationResponse,
    EvaluationResultItem,
)

from ..console import MosProgressBar, _humanize_value, _render_field_value, log, log_key_value_table, logger
from ..decorators import handle_http_errors, timeout_from_param


def _enum_value(value) -> str:
    """Return the wire string for an enum or pass through a raw string."""
    return value.value if hasattr(value, "value") else str(value)



def _gpt_model_label(gpt_model) -> str:
    """Format a GptModel enum or raw string as a human-readable label.

    Examples:
        gpt-5.4      -> GPT 5.4
        gpt-5-mini   -> GPT 5 Mini
        gpt_4o       -> GPT 4o
        gpt_4o_mini  -> GPT 4o Mini
        o3-mini      -> O3 Mini
    """
    raw = _enum_value(gpt_model)
    s = raw.replace("_", "-").strip("-")
    result = []
    for token in s.split("-"):
        if token.lower() == "gpt":
            result.append(token.upper())
        elif token[:1].isdigit() or "." in token:
            # Version number — keep as-is (e.g. "5.4", "4.1")
            result.append(token)
        else:
            result.append(token.capitalize())
    return " ".join(result)


def _get_root_error(e: Exception) -> str:
    """Walk the __cause__ chain and return all unique messages joined by ' → '."""
    parts = []
    seen: set[int] = set()
    current: BaseException | None = e
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        msg = str(current)
        if msg and msg not in parts:
            parts.append(msg)
        current = current.__cause__
    return " → ".join(parts) if parts else repr(e)


def _fmt_duration(seconds: float) -> str:
    """Format elapsed seconds as a readable string, e.g. '4m 23s'."""
    s = int(seconds)
    if s < 60:
        return f"{s}s"
    m, s = divmod(s, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m {s}s"


def _truncate(text: str, length: int = 80) -> str:
    return text if len(text) <= length else text[:length] + "…"


def _log_eval_start(
    req: EvaluationRequest,
    article_count: Optional[int],
    re_evaluate: bool = False,
) -> None:
    """Print a clean block before evaluation is submitted."""
    _EVAL_SKIP = {"article_search", "evaluation_prompts", "articles"}
    _SEARCH_SKIP = {"config"}

    rows: list[tuple[str, Any]] = []

    if article_count is not None:
        rows.append(("Articles", str(article_count)))

    for field_name in type(req.article_search).model_fields:
        if field_name in _SEARCH_SKIP:
            continue
        value = getattr(req.article_search, field_name)
        if value is None:
            continue
        rows.append((_humanize_value(field_name), _render_field_value(field_name, value)))

    for field_name in type(req).model_fields:
        if field_name in _EVAL_SKIP:
            continue
        value = getattr(req, field_name)
        if value is None:
            continue
        rows.append((_humanize_value(field_name), _render_field_value(field_name, value)))

    if req.articles:
        rows.append(("Articles", str(len(req.articles))))

    if re_evaluate:
        rows.append(("Re-evaluate", "Yes (cache bypassed)"))

    log_key_value_table("Starting Evaluation", rows)


def _log_eval_summary(
    evaluation_id: str,
    elapsed: float,
    evaluation: Optional[EvaluationHistory],
    timed_out: bool,
) -> None:
    """Print a clean summary block after evaluation finishes or times out."""
    url = f"{settings.mos_api_base}/?id={evaluation_id}"
    title = (
        "Evaluation Summary (still running on the server)"
        if timed_out
        else "Evaluation Summary"
    )

    counts = evaluation.aggregated_status_count if evaluation else None
    criteria = evaluation.aggregated_meets_criteria_count if evaluation else None
    total = (counts.total or 0) if counts else 0
    failed = (counts.failed or 0) if counts else 0
    status = evaluation.status if evaluation else "Active"
    abstract_counts = criteria.abstract.root if criteria else {}
    fulltext_counts = criteria.fulltext.root if criteria else {}
    abstract_yes = abstract_counts.get("Yes", 0)
    fulltext_yes = fulltext_counts.get("Yes", 0)
    eval_types = [_enum_value(t) for t in (evaluation.evaluation_types or [])] if evaluation else []
    is_full_text = EvaluationType.FULL_TEXT.value in eval_types

    rows: list[tuple[str, str]] = [
        ("Evaluation ID", evaluation_id),
        ("Status", str(status)),
        ("Time Taken", _fmt_duration(elapsed)),
        ("Articles Submitted", str(total)),
    ]
    # Only show "Abstract Passed" when the abstract phase actually ran
    # (signalled by non-empty abstract counts, OR when there are no eval_types
    # which implies the default abstract-only flow).
    if abstract_counts or not eval_types:
        rows.append(("Abstract Passed", str(abstract_yes)))
    if is_full_text or fulltext_counts:
        rows.append(("Full Text Passed", str(fulltext_yes)))
    if failed:
        rows.append(("Failed", str(failed)))
    rows.append(("Evaluation URL", url))
    log_key_value_table(title, rows)


def _log_eval_error(
    evaluation_id: Optional[str],
    elapsed: float,
    error: Exception,
) -> None:
    """Print a summary block when evaluation raises an unexpected error."""
    rows: list[tuple[str, str]] = []
    if evaluation_id:
        rows.append(("Evaluation ID", evaluation_id))
    rows.append(("Duration", _fmt_duration(elapsed)))
    rows.append(("Error", _get_root_error(error)))
    log_key_value_table("Evaluation Failed", rows)


def _log_eval_submitted(evaluation_id: str) -> None:
    """Print a table confirming the evaluation was queued successfully."""
    log_key_value_table(
        "Evaluation Submitted",
        [
            ("Evaluation ID", evaluation_id),
            ("Evaluation URL", f"{settings.mos_api_base}/?id={evaluation_id}"),
        ],
    )


class Evaluation:
    def __init__(self, mos):
        self.mos = mos

    @handle_http_errors
    @validate_call
    async def evaluate(
        self, evaluation_request: EvaluationRequest,
        timeout: int = Field(0, ge=0, le=3600, description="Timeout in seconds"),
        re_evaluate: bool = False
    ) -> EvaluationResponse:
        """
        Submits evaluation requests for asynchronous processing
        and optionally waits for their completion.

        This method sends a batch evaluation payload to the MOS Evaluation API,
        including search context, selected articles, evaluation criteria,
        GPT configuration, and resolved evaluation prompts. If the user does
        not supply specific evaluation prompts, the system automatically
        falls back to default prompts retrieved from the MOS prompt service.

        Once the evaluation request is successfully submitted, the API
        responds with one or more evaluation history IDs. If a timeout
        is provided, this method polls the evaluation history endpoint
        at fixed intervals until the evaluation completes, fails, or
        exceeds the specified timeout.

        Args:
            evaluation_request (EvaluationRequest):
                A fully populated evaluation request containing search
                parameters, selected articles, evaluation criteria,
                GPT configuration, and optional custom prompts.
            timeout (int, optional):
                Maximum time (in seconds) to wait for evaluation completion.
                If set to 0 (default), polling is disabled and evaluation
                history IDs are returned immediately.
            re_evaluate (bool, optional):
                If True, bypasses cached results and forces re-evaluation.
                Defaults to False.

        Returns:
            EvaluationResponse:
                An object containing the evaluation state and results. 
                The response includes:
                
                - id (str): The unique Evaluation history ID.
                - status (EvaluationStatus): The current state of the evaluation 
                  (e.g., PENDING, COMPLETED, FAILED).
                - evaluation (Optional[EvaluationHistory]): The detailed results 
                  populated only when the status is 'COMPLETED'.

                Note:
                - If polling is disabled (timeout=0), the status will reflect 
                  the immediate state after submission (usually PENDING/ACTIVE) 
                   and the evaluation data will be None.
                - If polling completes successfully within the timeout, 
                  the status will be COMPLETED and the evaluation results 
                  will be included.
                - If a timeout occurs, the response is returned with its 
                  last known status (e.g., PENDING).

        Raises:
            MosNetworkError:
                If a network connection issue occurs (DNS failure,
                connection timeout).
            MosAuthenticationError:
                If the API request is unauthorized (HTTP 401 or 403).
            MosApiError:
                If the MOS server returns a client (4xx) or server (5xx) error.
            MosError:
                If no evaluation IDs are returned, evaluation fails,
                polling times out, or an unexpected runtime error occurs.
        """
        started_at = time.time()
        evaluation_id: Optional[str] = None
        try:
            # Show config upfront; article count shown only when already provided
            _log_eval_start(
                evaluation_request,
                article_count=len(evaluation_request.articles) if evaluation_request.articles is not None else None,
                re_evaluate=re_evaluate,
            )

            # Resolve articles — run search inline when no pre-fetched articles
            # were supplied. Use a local so we don't mutate the caller's request
            # (which would silently skip the search on a second call).
            articles = evaluation_request.articles
            if articles is None:
                articles = await self.mos.search.articles(evaluation_request.article_search)

            default_prompts = await self.mos.prompts.defaults(
                category=DefaultPromptCategory.EVALUATION
            )

            selected_results = [article.model_dump() for article in articles]
            selected_sgrids = [article.sgrid for article in articles]
            sgrid_to_relevance_mappings = [
                {"sgrid": article.sgrid, "relevance": article.relevance}
                for article in articles
            ]
            eids = str(evaluation_request.article_search.eids) if evaluation_request.article_search.eids else ""
            eid = evaluation_request.article_search.eid or ""

            article_count = len(articles)
            log(f"Submitting evaluation for {article_count} articles…")

            url = f"{settings.mos_api_base}/api/evaluation/batch/submit"
            payload = {
                "evaluations": [{
                    # ---- SEARCH CONTEXT ----
                    "search_query": evaluation_request.article_search.search_query,
                    "search_type": evaluation_request.article_search.search_type,
                    "starting_year": evaluation_request.article_search.starting_year,
                    "source_types": evaluation_request.article_search.source_types,
                    "citation_types": evaluation_request.article_search.citation_types,
                    "sd_documents_only": evaluation_request.article_search.limit_to_science_direct,
                    "show_empty_abstracts": evaluation_request.article_search.show_empty_abstracts,
                    "results_per_page": evaluation_request.article_search.number_of_results,
                    "config": evaluation_request.article_search.config.model_dump(exclude_none=True) if evaluation_request.article_search.config else {},
                    "eid": eid,
                    "eids": eids,

                    # ---- CRITERIA ----
                    "criteria": evaluation_request.criteria,
                    "is_criteria_same_as_search_query": (
                        evaluation_request.is_criteria_same_as_search_query
                    ),

                    # ---- GPT CONFIG ----
                    "gpt_model": evaluation_request.gpt_config.gpt_model,
                    "reasoning_effort": evaluation_request.gpt_config.reasoning_effort,
                    "verbosity": evaluation_request.gpt_config.verbosity,
                    "temperature": evaluation_request.gpt_config.temperature,

                    # ---- ARTICLES ----
                    "selected_results": selected_results,
                    "selected_sgrids": selected_sgrids,
                    "sgrid_to_relevance_mappings": sgrid_to_relevance_mappings,

                    # ---- PROMPTS ----
                    "initial_prompt": evaluation_request.evaluation_prompts.abstract_initial_prompt or default_prompts.abstract_initial_prompt,
                    "final_prompt": evaluation_request.evaluation_prompts.abstract_final_prompt or default_prompts.abstract_final_prompt,

                    "abstract_meets_criteria_prompt":
                        evaluation_request.evaluation_prompts.abstract_meets_criteria_prompt or default_prompts.abstract_meets_criteria_prompt,
                    "abstract_rationale_prompt":
                        evaluation_request.evaluation_prompts.abstract_rationale_prompt or default_prompts.abstract_rationale_prompt,
                    "abstract_initial_prompt_strict":
                        evaluation_request.evaluation_prompts.abstract_initial_prompt_strict or default_prompts.abstract_initial_prompt_strict,
                    "abstract_final_prompt_strict":
                        evaluation_request.evaluation_prompts.abstract_final_prompt_strict or default_prompts.abstract_final_prompt_strict,
                    "abstract_meets_criteria_prompt_strict":
                        evaluation_request.evaluation_prompts.abstract_meets_criteria_prompt_strict or default_prompts.abstract_meets_criteria_prompt_strict,
                    "abstract_quotation_prompt_strict":
                        evaluation_request.evaluation_prompts.abstract_quotation_prompt_strict or default_prompts.abstract_quotation_prompt_strict,
                    "abstract_rationale_prompt_strict":
                        evaluation_request.evaluation_prompts.abstract_rationale_prompt_strict or default_prompts.abstract_rationale_prompt_strict,

                    "has_refined_question_prompt":
                        evaluation_request.evaluation_prompts.has_refined_question_prompt or default_prompts.has_refined_question_prompt,
                    "refined_question_prompt":
                        evaluation_request.evaluation_prompts.refined_question_prompt or default_prompts.refined_question_prompt,
                    "refined_question_field_prompt":
                        evaluation_request.evaluation_prompts.refined_question_field_prompt or default_prompts.refined_question_field_prompt,

                    "full_text_initial_prompt":
                        evaluation_request.evaluation_prompts.full_text_initial_prompt or default_prompts.full_text_initial_prompt,
                    "full_text_final_prompt":
                        evaluation_request.evaluation_prompts.full_text_final_prompt or default_prompts.full_text_final_prompt,
                    "full_text_meets_criteria_prompt":
                        evaluation_request.evaluation_prompts.full_text_meets_criteria_prompt or default_prompts.full_text_meets_criteria_prompt,
                    "full_text_quotation_prompt":
                        evaluation_request.evaluation_prompts.full_text_quotation_prompt or default_prompts.full_text_quotation_prompt,
                    "full_text_quotation_json_field_prompt":
                        evaluation_request.evaluation_prompts.full_text_quotation_json_field_prompt or default_prompts.full_text_quotation_json_field_prompt,
                    "full_text_rationale_prompt":
                        evaluation_request.evaluation_prompts.full_text_rationale_prompt or default_prompts.full_text_rationale_prompt,

                    "system_prompt":
                        evaluation_request.evaluation_prompts.system_prompt or default_prompts.system_prompt,
                    "criteria_prefix":
                        evaluation_request.evaluation_prompts.criteria_prefix or default_prompts.criteria_prefix,

                    # ---- FLAGS / TYPES ----
                    "evaluation_types": evaluation_request.evaluation_types,
                    "strict_abstract_evaluation_type":
                        evaluation_request.strict_abstract_evaluation_type,
                    "workflow_type": evaluation_request.workflow_type,


                }],
                "skip_cache": re_evaluate

            }
            response = await self.mos.http.post(
                url,
                json=payload,
                timeout=5 * 60,
            )

            response.raise_for_status()

            data = response.json()
            evaluation_ids = data.get("data", {}).get("evaluation_ids", [])

            if not evaluation_ids:
                raise MosError("No evaluation_ids returned from server")

            evaluation_id = evaluation_ids[0]
            _log_eval_submitted(evaluation_id)

            if timeout <= 0:
                log("Evaluation queued (no timeout set — returning immediately without waiting for completion)")
                return EvaluationResponse(
                    id=evaluation_id, status=EvaluationStatus.PENDING, evaluation=None
                )

            log(f"Polling for results — timeout={timeout}s")
            try:
                evaluation = await self._wait_for_completion(
                    evaluation_id, timeout=timeout
                )
                _log_eval_summary(evaluation_id, time.time() - started_at, evaluation, timed_out=False)
                return EvaluationResponse(
                    id=evaluation_id, status=evaluation.status, evaluation=evaluation
                )
            except MosTimeoutError:
                # Fetch one last snapshot to populate the summary with real counts
                try:
                    last_eval = await self.get(evaluation_id)
                except Exception:
                    last_eval = None
                _log_eval_summary(evaluation_id, time.time() - started_at, last_eval, timed_out=True)
                return EvaluationResponse(
                    id=evaluation_id, status=EvaluationStatus.PENDING, evaluation=None
                )

        except MosError as e:
            # Preserve typed errors (MosNetworkError, MosAuthenticationError,
            # MosApiError, etc.) so callers can catch them specifically.
            _log_eval_error(evaluation_id=evaluation_id, elapsed=time.time() - started_at, error=e)
            raise
        except Exception as e:
            _log_eval_error(evaluation_id=evaluation_id, elapsed=time.time() - started_at, error=e)
            raise MosError("Evaluation failed") from e

    @handle_http_errors
    @validate_call
    async def re_evaluate(
        self,
        evaluation_request: EvaluationRequest,
        timeout: int = Field(0, ge=0, le=3600, description="Timeout in seconds"),
    ) -> EvaluationResponse:
        """
        A shortcut method to force the re-evaluation of articles.

        This method performs the same logic as `evaluate`, but explicitly sets 
        the `re_evaluate` flag to True. This bypasses any existing cached 
        results and forces the MOS Evaluation API to perform a fresh analysis 
        based on the provided criteria.

        Args:
            evaluation_request (EvaluationRequest): 
                A fully populated evaluation request containing search 
                parameters, articles, criteria, and GPT configuration.
            timeout (int, optional): 
                Maximum time (in seconds) to wait for evaluation completion. 
                Defaults to 0 (no polling).

        Returns:
            EvaluationResponse:
                An object containing the evaluation state and results. 
                The response includes:
                
                - id (str): The unique Evaluation history ID.
                - status (EvaluationStatus): The current state of the evaluation 
                  (e.g., PENDING, COMPLETED, FAILED).
                - evaluation (Optional[EvaluationHistory]): The detailed results 
                  populated only when the status is 'COMPLETED'.

                Note:
                - If polling is disabled (timeout=0), the status will reflect 
                  the immediate state after submission (usually PENDING/ACTIVE) 
                   and the evaluation data will be None.
                - If polling completes successfully within the timeout, 
                  the status will be COMPLETED and the evaluation results 
                  will be included.
                - If a timeout occurs, the response is returned with its 
                  last known status (e.g., PENDING).

        Raises:
            MosNetworkError:
                If a network connection issue occurs (DNS failure,
                connection timeout).
            MosAuthenticationError:
                If the API request is unauthorized (HTTP 401 or 403).
            MosApiError:
                If the MOS server returns a client (4xx) or server (5xx) error.
            MosError:
                If no evaluation IDs are returned, evaluation fails,
                polling times out, or an unexpected runtime error occurs.
        """
        return await self.evaluate(
            evaluation_request=evaluation_request, timeout=timeout, re_evaluate=True
        )

    @handle_http_errors
    @validate_call
    async def get(self, evaluation_id: str) -> EvaluationHistory:
        """
        Retrieve the current status and results of an evaluation by ID.

        This method queries the MOS Evaluation History API to fetch the
        latest state of an evaluation request previously submitted via
        `evaluate()`. It then hydrates the full evaluation results by
        calling the batch results endpoint.

        This method does **not** perform polling by itself. For automatic
        polling until completion, use `evaluate(..., timeout>0)` instead.

        Args:
            evaluation_id (str):
                The evaluation history ID returned by the `evaluate()` method.

        Returns:
            EvaluationHistory:
                A fully hydrated evaluation record including:
                  - `status` (e.g. "Pending", "Active", "Completed", "Failed")
                  - `evaluation_results` (full result objects)
                  - timestamps and other server-side fields

        Raises:
            MosNetworkError:
                If a network or connection issue occurs.
            MosAuthenticationError:
                If the request is unauthorized (HTTP 401 or 403).
            MosApiError:
                If the MOS server returns a client or server error.
            MosError:
                If the response is malformed or an unexpected error occurs.
        """
        try:
            api_response = await self._get_status(evaluation_id)

            evaluation_results = []
            if api_response.evaluated_results:
                evaluation_results = await self._fetch_results_batch(
                    evaluation_id, api_response.evaluated_results
                )

            return EvaluationHistory(
                **api_response.model_dump(exclude={"evaluated_results"}),
                evaluation_results=evaluation_results,
            )

        except MosError:
            raise
        except Exception as e:
            raise MosError("Unexpected error while fetching evaluation status") from e

    async def _get_status(self, evaluation_id: str) -> EvaluationHistoryApiResponse:
        """
        Fetch evaluation history metadata without hydrating results.
        Used internally for lightweight polling.
        """
        url = f"{settings.mos_api_base}/api/evaluation/history/{evaluation_id}"

        response = await self.mos.http.get(url)
        response.raise_for_status()

        data = response.json().get("data")
        if data is None:
            raise MosError(
                f"No evaluation data returned for evaluation_id={evaluation_id}"
            )
        return EvaluationHistoryApiResponse(**data)

    async def _fetch_results_batch(
        self, evaluation_id: str, result_ids: List[str]
    ) -> List[EvaluationResultItem]:
        """
        Fetch full evaluation result objects via the batch endpoint.
        """
        url = f"{settings.mos_api_base}/api/evaluation/results/batch"
        payload = {
            "evaluation_id": evaluation_id,
            "evaluation_result_ids": result_ids,
        }

        response = await self.mos.http.post(url, json=payload)
        response.raise_for_status()

        results_data = response.json().get("data", [])
        return [EvaluationResultItem(**item) for item in results_data]

    @handle_http_errors
    @timeout_from_param("timeout")
    async def _wait_for_completion(self, history_id: str, *, timeout: int, poll_interval: int = 5) -> EvaluationHistory:

        if timeout <= 0:
            raise MosError("Internal error: polling called with timeout <= 0")

        max_consecutive_errors = 5
        consecutive_errors = 0
        progress_bar: MosProgressBar | None = None
        terminal_states = {
            EvaluationStatus.COMPLETED,
            EvaluationStatus.FAILED,
            EvaluationStatus.CANCELLED,
        }

        try:
            while True:
                try:
                    api_response = await self._get_status(history_id)
                    consecutive_errors = 0
                except Exception as poll_err:
                    consecutive_errors += 1
                    logger.warning(
                        "Failed to fetch evaluation status "
                        f"(attempt {consecutive_errors}/{max_consecutive_errors}): "
                        f"{type(poll_err).__name__}: {poll_err} — retrying …"
                    )
                    if consecutive_errors >= max_consecutive_errors:
                        logger.error(
                            f"Maximum consecutive errors reached ({max_consecutive_errors}) — aborting poll"
                        )
                        raise
                    await asyncio.sleep(poll_interval)
                    continue

                status = api_response.status
                counts = api_response.aggregated_status_count
                total = counts.total or 0
                completed = counts.completed or 0
                pending = counts.pending or 0
                active = counts.active or 0
                failed = counts.failed or 0

                # Initialise the progress bar lazily once we know the total
                if progress_bar is None and total > 0:
                    progress_bar = MosProgressBar(
                        label=f"Evaluating articles [{history_id[:8]}…]",
                        total=total,
                        unit="articles",
                    )

                if progress_bar is not None:
                    progress_bar.update(completed)
                    progress_bar.set_status(active=active, pending=pending, failed=failed)

                if status in terminal_states:
                    if progress_bar is not None:
                        progress_bar.close(status=str(status).lower())
                        progress_bar = None  # don't double-close in finally
                    evaluation_results = []
                    if api_response.evaluated_results:
                        evaluation_results = await self._fetch_results_batch(
                            history_id, api_response.evaluated_results
                        )
                    return EvaluationHistory(
                        **api_response.model_dump(exclude={"evaluated_results"}),
                        evaluation_results=evaluation_results,
                    )

                await asyncio.sleep(poll_interval)
        finally:
            # Restore terminal state if we exit without hitting a terminal status
            # (timeout cancellation, asyncio.CancelledError, network error, etc.).
            if progress_bar is not None:
                progress_bar.close(status="stopped")
