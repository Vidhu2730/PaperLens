from mos.exceptions import MosError
from mos.models import ESQueryGenerationRequest
from pydantic import validate_call
from ..decorators import ensure_auth, handle_http_errors
from mos.config import settings
from mos.enums import DefaultPromptCategory


class ESQuery:

    def __init__(self, mos):
        self.mos = mos

    async def _resolve_prompt(self, user_prompt) -> str:
        """
        Resolves which prompt should be used for extraction.

        Returns the user-supplied prompt if provided. Otherwise,
        fetches and returns the appropriate system default prompt
        based on the prompt_type.
        """
        if user_prompt:
            return user_prompt

        prompt = await self.mos.prompts.defaults(category=DefaultPromptCategory.ES_SEARCH_QUERY)
        prompt_json = prompt.model_dump()
        return prompt_json.get("convert_es_search_query_prompt")


    @handle_http_errors
    @validate_call
    @ensure_auth
    async def generate_from_criteria_list(
            self, request: ESQueryGenerationRequest
    ) -> str:
        """
        Generates an Elasticsearch (ES) query string based on a list of criteria and a base prompt.

        This method resolves the provided prompt template and sends a request to the MOS API
        to transform natural language criteria and configuration into a structured ES search 
        query. It leverages specified GPT model parameters to control the reasoning and 
        format of the output.

        Args:
            request (ESQueryGenerationRequest): A configuration object containing the list 
                of search criteria, the prompt template, and GPT-specific parameters 
                (model, temperature, reasoning effort, etc.).

        Returns:
            str: The generated Elasticsearch query string returned by the API.

        Raises:
            MosNetworkError: If a network connection issue occurs (DNS, Timeout).
            MosAuthenticationError: If the API request is unauthorized (401/403).
            MosApiError: If the MOS server returns a client (4xx) or server (5xx) error.
            MosError: If an unexpected runtime error occurs during processing.
        """
        try:
            prompt = await self._resolve_prompt(request.prompt)
            url = f"{settings.mos_api_base}/api/search/convert-to-es-search-query"
            payload = {
                "criterias": request.criteria_list,
                "base_prompt": prompt,
                "gpt_model": request.gpt_config.gpt_model,
                "reasoning_effort": request.gpt_config.reasoning_effort,
                "verbosity": request.gpt_config.verbosity,
                "temperature": request.gpt_config.temperature
            }
            response = await self.mos.http.post(
                url,
                json=payload,
                timeout=5 * 60,
            )

            response.raise_for_status()

            es_query_response = response.json()
            return es_query_response.get("data")

        except Exception as e:
            raise MosError("Failed to generate search query") from e

