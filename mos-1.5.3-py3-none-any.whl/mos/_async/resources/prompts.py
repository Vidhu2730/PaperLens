from typing import Literal, Union, overload

from ..decorators import handle_http_errors
from mos.enums import DefaultPromptCategory
from mos.exceptions import MosError
from mos.models import (
    DefaultPrompts,
    EsSearchQueryPrompts,
    EvaluationPrompts,
    ExtractCriteriaPrompts,
    DeepSearchPrompts
)
from pydantic import validate_call
from mos.config import settings


class Prompts:
    def __init__(self, mos):
        self.mos = mos

    # Case 1: type is EXTRACT_CRITERIA -> Returns ExtractCriteriaPrompts object
    @overload
    async def defaults(
        self, category: Literal[DefaultPromptCategory.EXTRACT_CRITERIA]
    ) -> ExtractCriteriaPrompts: ...

    # Case 2: type is ES_SEARCH_QUERY -> Returns EsSearchQueryPrompts object
    @overload
    async def defaults(
        self, category: Literal[DefaultPromptCategory.ES_SEARCH_QUERY]
    ) -> EsSearchQueryPrompts: ...

    # Case 3: type is EVALUATION -> Returns EvaluationPrompts object
    @overload
    async def defaults(
        self, category: Literal[DefaultPromptCategory.EVALUATION]
    ) -> EvaluationPrompts: ...

    # Case 4: type is DEEP_SEARCH -> Returns DeepSearchPrompts object
    @overload
    async def defaults(
        self, category: Literal[DefaultPromptCategory.DEEP_SEARCH]
    ) -> DeepSearchPrompts: ...

    # Case 5: type is None -> Returns DefaultPrompts object
    @overload
    async def defaults(self, category: None = None) -> DefaultPrompts: ...

    @handle_http_errors
    @validate_call
    async def defaults(
        self, category: DefaultPromptCategory = None
    ) -> Union[
        ExtractCriteriaPrompts, EsSearchQueryPrompts, EvaluationPrompts, DeepSearchPrompts, DefaultPrompts
    ]:
        """
        Retrieves default system prompts, optionally filtered by type.

        This method fetches the default configuration of prompts used for
        operations like criteria extraction, search query conversion, evaluation, and deep search.
        If a `type` is provided, only prompts associated with that category are returned.

        Args:
            type (DefaultPromptType, optional): The specific category of prompts to retrieve
                (e.g., 'extract-criteria', 'evaluation', 'deep-search'). If None, all available
                prompts are returned.

        Returns:
            Dict[str, str]: A dictionary mapping prompt keys (names) to their text content.
                Returns an empty dictionary if the API response contains no data.

        Raises:
            MosNetworkError: If a network connection issue occurs (DNS, Timeout).
            MosAuthenticationError: If the API request is unauthorized (401/403).
            MosApiError: If the MOS server returns a client (4xx) or server (5xx) error.
            MosError: If an unexpected runtime error occurs during processing.
        """
        try:
            url = f"{settings.mos_api_base}/api/v1/prompts"

            query_params = {}
            if category is not None:
                query_params["category"] = category.value

            response = await self.mos.http.get(
                url,
                params=query_params,
                timeout=5 * 60,
            )

            response.raise_for_status()

            data = response.json().get("data", {})

            if category == DefaultPromptCategory.EXTRACT_CRITERIA:
                return ExtractCriteriaPrompts(**data)

            elif category == DefaultPromptCategory.ES_SEARCH_QUERY:
                return EsSearchQueryPrompts(**data)

            elif category == DefaultPromptCategory.EVALUATION:
                return EvaluationPrompts(**data)
            
            elif category == DefaultPromptCategory.DEEP_SEARCH:
                return DeepSearchPrompts(**data)
            else:
                return DefaultPrompts(**data)
        except Exception as e:
            raise MosError("Failed to fetch default prompts") from e
