import json
from collections.abc import AsyncIterator

from mos.config import settings
from mos.exceptions import MosError
from mos.models import LLMChatRequest, LLMChatResponse, LLMStreamEvent
from pydantic import ValidationError, validate_call

from ..decorators import handle_http_errors


class LLM:
    def __init__(self, mos):
        self.mos = mos

    def _payload(self, request: LLMChatRequest, *, stream: bool) -> dict:
        gpt_config = request.gpt_config
        return {
            "messages": [message.model_dump() for message in request.messages],
            "gpt_model": gpt_config.gpt_model.value,
            "stream": stream,
            "reasoning_effort": getattr(gpt_config.reasoning_effort, "value", None),
            "verbosity": getattr(gpt_config.verbosity, "value", None),
            "temperature": gpt_config.temperature,
            "response_format": request.response_format,
            "extra_params": request.extra_params,
        }

    @handle_http_errors
    @validate_call
    async def chat(self, request: LLMChatRequest) -> LLMChatResponse:
        """
        Execute a non-streaming Azure OpenAI chat request through the MOS proxy.
        """
        try:
            url = f"{settings.mos_api_base}/api/v1/llm/chat"
            response = await self.mos.http.post(
                url,
                json=self._payload(request, stream=False),
                timeout=10 * 60,
            )
            response.raise_for_status()
            return LLMChatResponse(**response.json().get("data", {}))
        except Exception as e:
            raise MosError("Failed to execute LLM chat request") from e

    @handle_http_errors
    @validate_call
    async def stream_chat(
        self,
        request: LLMChatRequest,
    ) -> AsyncIterator[LLMStreamEvent]:
        """
        Stream an Azure OpenAI chat response through the MOS proxy.
        """
        try:
            url = f"{settings.mos_api_base}/api/v1/llm/chat"
            async with self.mos.http.client.stream(
                "POST",
                url,
                headers=await self.mos.http._auth_headers({"Accept": "text/event-stream"}),
                json=self._payload(request, stream=True),
                timeout=10 * 60,
            ) as stream_response:
                stream_response.raise_for_status()
                buffer = ""

                async for chunk in stream_response.aiter_text():
                    buffer += chunk
                    while "\n\n" in buffer:
                        raw_event, buffer = buffer.split("\n\n", 1)
                        data_lines = [
                            line[5:].lstrip()
                            for line in raw_event.splitlines()
                            if line.startswith("data:")
                        ]
                        if not data_lines:
                            continue
                        json_str = "\n".join(data_lines).strip()
                        if not json_str:
                            continue
                        try:
                            yield LLMStreamEvent(**json.loads(json_str))
                        except (json.JSONDecodeError, ValidationError):
                            continue
        except Exception as e:
            raise MosError("Failed to stream LLM chat request") from e

