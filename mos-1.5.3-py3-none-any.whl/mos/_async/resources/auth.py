import time
from mos.config import settings
from ..decorators import handle_http_errors
import asyncio
from mos.config import settings

class Auth:
    def __init__(self, mos):
        """Initialize authentication state."""
        self._token = None
        self._token_expiry = 0
        self._auth_lock = asyncio.Lock()

        self.mos = mos

    @handle_http_errors
    async def _authenticate(self):
        """
        Fetches aws cognito token using Client Credentials Flow (Machine-to-Machine).
        """
        url = f"{settings.cognito_domain}/oauth2/token"
        payload = {"grant_type": "client_credentials", "scope": settings.auth_scope}

        response = await self.mos.http.client.post(
            url, data=payload, auth=(self.mos.client_id, self.mos.client_secret)
        )

        response.raise_for_status()

        # Get Token
        data = response.json()
        self._token = data.get("access_token")
        # Calculate expiry with buffer
        self._token_expiry = (
            time.time()
            + data.get("expires_in", 3600)
            - settings.token_buffer_seconds
        )

    async def _ensure_token(self):
        """Checks validity and refreshes if needed using double-checked locking."""
        # Check 1: Fast check without lock
        if self._token and time.time() < self._token_expiry:
            return

        # Check 2: Thread-safe check with lock
        async with self._auth_lock:
            if self._token and time.time() < self._token_expiry:
                return
            await self._authenticate()
