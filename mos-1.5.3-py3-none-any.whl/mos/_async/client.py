from .resources.es_query import ESQuery
from .resources.extract_criteria import ExtractCriteria
from .resources.llm import LLM
from .resources.search import Search
from .resources.prompts import Prompts
from .resources.auth import Auth
from .resources.evaluation import Evaluation
from .http_client import HTTPClient

class AsyncMos():
    def __init__(self, client_id, client_secret):
        """
        Initializes the asynchronous MOS client with credentials.

        Args:
            client_id (str): The unique Client ID provided.
            client_secret (str): The secret key associated with the Client ID
                for secure authentication.
        """
        self.client_id = client_id
        self.client_secret = client_secret

        self.http = HTTPClient(self)
        self.prompts = Prompts(self)
        self.auth = Auth(self)
        self.search = Search(self)
        self.evaluation = Evaluation(self)
        self.extract_criteria = ExtractCriteria(self)
        self.es_query = ESQuery(self)
        self.llm = LLM(self)

    @property
    def token(self) -> str:
        """
        Shortcut for token property
        """
        return self.auth._token
