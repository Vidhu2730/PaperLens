from datetime import datetime
from typing import List, Literal, Optional, Dict, Any
from urllib.parse import urlparse
from pydantic import BaseModel, Field, FilePath, field_validator, model_validator, RootModel
from mos.enums import (
    ALL_CITATION_TYPES,
    ALL_SOURCE_TYPES,
    CitationType,
    SearchType,
    SourceType,
    ReasoningEffort,
    Verbosity,
    GptModel,
    EvaluationType,
    StrictAbstractEvaluationType,
    ExtractCriteriaPromptType,
    EvaluationStatus,
    ExpansionLevel
)

DEFAULT_CRITERIA_PREFIX = (
    "Articles providing new evidence specifically on the following:"
)


class GptModelConfig(BaseModel):
    """
    Encapsulates all parameters required for gpt model selection
    """
    gpt_model: GptModel = Field(..., description="GPT model name")
    reasoning_effort: Optional[ReasoningEffort] = Field(default=None, description="Reasoning effort level")
    verbosity: Optional[Verbosity] = Field(default=None, description="Verbosity level")
    temperature: Optional[float] = Field(default=None, description="Sampling temperature")

    # Field-level validation
    @field_validator("temperature")
    @classmethod
    def validate_temperature(cls, v):
        if v is not None and not (0 <= v <= 2):
            raise ValueError("temperature must be between 0 and 2")
        return v

    def _validate_re(self, allowed_reasoning: set[ReasoningEffort]):
        if self.reasoning_effort not in allowed_reasoning:
            raise ValueError(
                f"{self.gpt_model} supports reasoning_effort: "
                f"{[e.value for e in allowed_reasoning]}"
            )

    def _validate_verbosity(self, allowed_verbosity: set[Verbosity]):
        if self.verbosity not in allowed_verbosity:
            raise ValueError(
                f"{self.gpt_model} supports verbosity: "
                f"{[v.value for v in allowed_verbosity]}"
            )

    def _validate_no_verbosity(self):
        if self.verbosity is not None:
            raise ValueError(
                f"verbosity is not supported for model '{self.gpt_model}'"
            )

    # Cross-field validation
    @model_validator(mode="after")
    def validate_model_constraints(self):
        model = self.gpt_model

        is_gpt5 = model in {GptModel.gpt_5, GptModel.gpt_5_mini,
                            GptModel.gpt_5_nano, GptModel.gpt_5_1, GptModel.gpt_5_2,
                            GptModel.gpt_5_4, GptModel.gpt_5_4_pro, GptModel.gpt_5_5}
        is_gpt5_with_minimal = model in {GptModel.gpt_5, GptModel.gpt_5_mini, GptModel.gpt_5_nano}
        is_o3 = model == GptModel.o3_mini
        is_o4 = model == GptModel.o4_mini

        # 1. Temperature rules
        if not (is_gpt5 or is_o3 or is_o4):
            if self.temperature is None:
                raise ValueError(
                    f"temperature is required for model '{self.gpt_model}'"
                )
        else:
            if self.temperature is not None:
                raise ValueError(
                    f"temperature is NOT supported for model '{self.gpt_model}'"
                )

        # 2. o3-mini / o4-mini
        if is_o3 or is_o4:
            allowed = {
                ReasoningEffort.low,
                ReasoningEffort.medium,
                ReasoningEffort.high,
            }
            self._validate_re(allowed)
            self._validate_no_verbosity()

        # 3. gpt-5 (except 5.1, 5.2)
        elif is_gpt5_with_minimal:
            allowed_reasoning = {
                ReasoningEffort.minimal,
                ReasoningEffort.low,
                ReasoningEffort.medium,
                ReasoningEffort.high,
            }
            allowed_verbosity = {
                Verbosity.low,
                Verbosity.medium,
                Verbosity.high,
            }
            self._validate_re(allowed_reasoning)
            self._validate_verbosity(allowed_verbosity)

        # 4. gpt-5.1
        elif self.gpt_model == GptModel.gpt_5_1:
            allowed_reasoning = {
                ReasoningEffort.none,
                ReasoningEffort.low,
                ReasoningEffort.medium,
                ReasoningEffort.high,
            }
            allowed_verbosity = {
                Verbosity.low,
                Verbosity.medium,
                Verbosity.high,
            }
            self._validate_re(allowed_reasoning)
            self._validate_verbosity(allowed_verbosity)

        # 5. gpt-5.2 / gpt-5.4 / gpt-5.5
        elif self.gpt_model in {GptModel.gpt_5_2, GptModel.gpt_5_4, GptModel.gpt_5_5}:
            allowed_reasoning = {
                ReasoningEffort.none,
                ReasoningEffort.low,
                ReasoningEffort.medium,
                ReasoningEffort.high,
                ReasoningEffort.xhigh,
            }
            allowed_verbosity = {
                Verbosity.low,
                Verbosity.medium,
                Verbosity.high,
            }
            self._validate_re(allowed_reasoning)
            self._validate_verbosity(allowed_verbosity)

        # 6. gpt-5.4-pro
        elif self.gpt_model == GptModel.gpt_5_4_pro:
            allowed_reasoning = {
                ReasoningEffort.medium,
                ReasoningEffort.high,
                ReasoningEffort.xhigh,
            }
            allowed_verbosity = {
                Verbosity.low,
                Verbosity.medium,
                Verbosity.high,
            }
            self._validate_re(allowed_reasoning)
            self._validate_verbosity(allowed_verbosity)

        return self
    

class GPTConfig(BaseModel):
    gpt_model: str = "gpt-5.2"
    reasoning_effort: Optional[str] = "medium"
    verbosity: Optional[str] = "low"
    temperature: Optional[float] = 0.7


class LLMChatMessage(BaseModel):
    role: Literal["system", "developer", "user", "assistant"]
    content: Any


class LLMChatRequest(BaseModel):
    messages: List[LLMChatMessage]
    gpt_config: GptModelConfig
    response_format: Optional[Dict[str, Any]] = None
    extra_params: Dict[str, Any] = Field(default_factory=dict)


class LLMChatResponse(BaseModel):
    content: str
    model: str


class LLMStreamEvent(BaseModel):
    delta: Optional[str] = None
    done: Optional[bool] = None
    error: Optional[str] = None


class NormalizeConfig(BaseModel):
    enabled: Optional[bool] = True
    prompt: Optional[str] = None
    gpt_config: Optional[GPTConfig] = Field(default_factory=GPTConfig)


class GenerateEsQueryConfig(BaseModel):
    number_of_iterations: Optional[int] = 3
    prompt: Optional[str] = None
    gpt_config: Optional[GPTConfig] = Field(default_factory=GPTConfig)


class SeedCandidateEvaluationConfig(BaseModel):
    enabled: Optional[bool] = True
    expansion_level: Optional[ExpansionLevel] = ExpansionLevel.BALANCED
    pass_criteria: Optional[Literal["abstract_only", "abstract_and_full_text"]] = "abstract_only"


class ToggleableExpansionConfig(BaseModel):
    enabled: Optional[bool] = True
    expansion_level: Optional[ExpansionLevel] = ExpansionLevel.BALANCED


class DeepSearchConfig(BaseModel):
    normalize: Optional[NormalizeConfig] = Field(default_factory=NormalizeConfig)
    create_variations: Optional[NormalizeConfig] = Field(default_factory=NormalizeConfig)
    generate_es_query: Optional[GenerateEsQueryConfig] = Field(default_factory=GenerateEsQueryConfig)
    lexical_search: Optional[ToggleableExpansionConfig] = Field(default_factory=ToggleableExpansionConfig)
    vector_search: Optional[ToggleableExpansionConfig] = Field(default_factory=ToggleableExpansionConfig)
    seed_candidate_evaluation: Optional[SeedCandidateEvaluationConfig] = Field(default_factory=SeedCandidateEvaluationConfig)
    seed_selection: Optional[ToggleableExpansionConfig] = Field(default_factory=ToggleableExpansionConfig)
    cited_by_expansion: Optional[ToggleableExpansionConfig] = Field(default_factory=ToggleableExpansionConfig)
    references_expansion: Optional[ToggleableExpansionConfig] = Field(default_factory=ToggleableExpansionConfig)
    author_articles_expansion: Optional[ToggleableExpansionConfig] = Field(default_factory=ToggleableExpansionConfig)
    vector_expansion: Optional[ToggleableExpansionConfig] = Field(default_factory=ToggleableExpansionConfig)


class SearchConfig(BaseModel):
    deep_search: Optional[DeepSearchConfig] = Field(default_factory=DeepSearchConfig)


class ArticleSearch(BaseModel):
    """
    Encapsulates all parameters required for searching articles.
    """

    search_query: Optional[str] = Field(None, description="Query string")
    search_type: SearchType = Field(..., description="Search Type to use")

    starting_year: int = Field(..., ge=1986, description="Start year (1900+)")
    number_of_results: int = Field(
        10, ge=1, le=10000, description="Maximum number of article results"
    )
    eid: Optional[str] = Field(
        None, description="EID for which citations need to be searched"
    )

    eids: Optional[List[str]] = Field(
        None, description="List of EIDs for which search needs to be performed"
    )
    author_ids: Optional[List[str]] = Field(
        None, description="List of Author IDs for which search needs to be performed"
    )

    config: Optional[SearchConfig] = Field(default_factory=SearchConfig)

    # Complex fields with defaults
    source_types: List[SourceType] = Field(default_factory=lambda: ALL_SOURCE_TYPES)
    citation_types: List[CitationType] = Field(
        default_factory=lambda: ALL_CITATION_TYPES
    )

    show_empty_abstracts: bool = False
    limit_to_science_direct: bool = False

    @field_validator("starting_year")
    @classmethod
    def validate_year(cls, v):
        if v > datetime.now().year:
            raise ValueError("Year cannot be in the future")
        return v

    @model_validator(mode="after")
    def validate_search_type_requirements(self):
        if self.search_type == SearchType.CITATION_SEARCH and not self.eid:
            raise ValueError(
                "eid is mandatory when search_type is CITATION_SEARCH"
            )

        if self.search_type == SearchType.EIDS_SEARCH and not self.eids:
            raise ValueError(
                "eids is mandatory when search_type is EIDS_SEARCH"
            )

        return self


class ScopusAuthor(BaseModel):
    """
    Represents an author associated with a scopus article
    """

    auid: str
    initials: str
    familyName: str
    givenName: str


class ScopusArticle(BaseModel):
    """
    Represents a scopus article
    """

    title: str
    abstract: str
    authors: List[ScopusAuthor]
    source_title: str
    keywords: List[str]
    relevance: str
    year: int
    DOI: str
    sgrid: str
    scopus_link: str
    pii: str
    deep_search_source_tags: Optional[List[str]] = []


class DeepSearchEvent(BaseModel):
    """
    Represents a single SSE event from the deep-search stream.
    """
    type: str = Field(..., description="Event type: progress, completed, error, started, cancelled")
    message: Optional[str] = None
    progress: Optional[float] = None
    append: Optional[bool] = False
    payload: Optional[List[Dict[str, Any]]] = None


class EvaluationPromptsPartial(BaseModel):
    system_prompt: Optional[str] = None
    criteria_prefix: Optional[str] = None
    abstract_initial_prompt: Optional[str] = None
    abstract_final_prompt: Optional[str] = None
    abstract_rationale_prompt: Optional[str] = None
    abstract_meets_criteria_prompt: Optional[str] = None
    abstract_initial_prompt_strict: Optional[str] = None
    abstract_final_prompt_strict: Optional[str] = None
    abstract_rationale_prompt_strict: Optional[str] = None
    abstract_quotation_prompt_strict: Optional[str] = None
    abstract_meets_criteria_prompt_strict: Optional[str] = None
    refined_question_prompt: Optional[str] = None
    refined_question_field_prompt: Optional[str] = None
    has_refined_question_prompt: Optional[str] = None
    full_text_initial_prompt: Optional[str] = None
    full_text_final_prompt: Optional[str] = None
    full_text_quotation_prompt: Optional[str] = None
    full_text_rationale_prompt: Optional[str] = None
    full_text_quotation_json_field_prompt: Optional[str] = None
    full_text_meets_criteria_prompt: Optional[str] = None


class EvaluationRequest(BaseModel):
    article_search: ArticleSearch

    # Core search context
    criteria: str = Field(..., description="criteria string")

    # GPT / evaluation config
    gpt_config: GptModelConfig = Field(default_factory=GptModelConfig)

    # Article selection
    articles: Optional[List[ScopusArticle]] = None

    # Prompts
    evaluation_prompts: EvaluationPromptsPartial = Field(default_factory=EvaluationPromptsPartial)

    # Filters / flags
    evaluation_types: Optional[List[EvaluationType]] = Field(default_factory=list)
    is_criteria_same_as_search_query: bool = False
    strict_abstract_evaluation_type: StrictAbstractEvaluationType = (
        StrictAbstractEvaluationType.NO_ARTICLES
    )
    workflow_type: Optional[Literal["search_only", "search_and_evaluate"]] = "search_only"

    @model_validator(mode="after")
    def validate_article_source(self):
        """
        Ensure at least one of article_search or articles is provided.
        """
        if not self.article_search and not self.articles:
            raise ValueError(
                "You must provide either 'article_search' or 'articles'."
            )
        return self

class DeepSearchPrompts(BaseModel):
    normalize_query_prompt: str
    topic_variations_prompt: str

class ExtractCriteriaPrompts(BaseModel):
    extract_criteria_prompt: str
    systematic_review_prompt: str


class EsSearchQueryPrompts(BaseModel):
    convert_es_search_query_prompt: str


class EvaluationPrompts(BaseModel):
    system_prompt: str
    criteria_prefix: str
    abstract_initial_prompt: str
    abstract_final_prompt: str
    abstract_rationale_prompt: str
    abstract_meets_criteria_prompt: str
    abstract_initial_prompt_strict: str
    abstract_final_prompt_strict: str
    abstract_rationale_prompt_strict: str
    abstract_quotation_prompt_strict: str
    abstract_meets_criteria_prompt_strict: str
    refined_question_prompt: str
    refined_question_field_prompt: str
    has_refined_question_prompt: str
    full_text_initial_prompt: str
    full_text_final_prompt: str
    full_text_quotation_prompt: str
    full_text_rationale_prompt: str
    full_text_quotation_json_field_prompt: str
    full_text_meets_criteria_prompt: str


class DefaultPrompts(ExtractCriteriaPrompts, EsSearchQueryPrompts, EvaluationPrompts, DeepSearchPrompts):
    pass


class BaseExtractionPrompt(BaseModel):
    prompt_type: Optional[ExtractCriteriaPromptType] = ExtractCriteriaPromptType.DEFAULT
    prompt: Optional[str] = None

    @model_validator(mode="after")
    def validate_prompt_configuration(self):
        if not self.prompt and not self.prompt_type:
            raise ValueError(
                "You must provide either a 'prompt_type' or a custom 'prompt'."
            )

        return self


class ExtractCriteriaFromPdf(BaseExtractionPrompt):
    file_path: FilePath = Field(..., description="Path to a PDF file")
    gpt_config: GptModelConfig

    @field_validator("file_path")
    @classmethod
    def validate_pdf_details(cls, value):        
        # Check Extension
        if value.suffix.lower() != ".pdf":
            raise ValueError("File must be a PDF (.pdf)")

        # Check Size
        if value.stat().st_size == 0:
            raise ValueError("PDF file is empty")
        
        return value


class ExtractCriteriaFromSD(BaseExtractionPrompt):
    uri: str = Field(..., description="ScienceDirect URL or Unformatted PII")
    gpt_config: GptModelConfig

    @field_validator("uri")
    @classmethod
    def validate_sd_uri(cls, value: str):
        cleaned = value.strip()

        # Case 1: URL
        if cleaned.startswith(("http://", "https://")):
            parsed = urlparse(cleaned)

            if not parsed.scheme or not parsed.netloc:
                raise ValueError("Invalid URL format")

            last_part = parsed.path.rstrip("/").split("/")[-1]

            if not last_part:
                raise ValueError("URL must contain a valid Unformatted-PII segment")

            if not last_part.isalnum():
                raise ValueError("Invalid URL: last path segment must be a valid Unformatted-PII")

            return cleaned

        # Case 2: Raw PII string
        if not cleaned.isalnum():
            raise ValueError("PII must be alphanumeric (Unformatted-PII)")

        return cleaned


class ESQueryGenerationRequest(BaseModel):
    criteria_list: List[str]
    prompt: Optional[str] = None
    gpt_config: GptModelConfig


class AggregatedCount(RootModel[dict[str, int]]):
    pass


class SgridRelevanceMapping(BaseModel):
    sgrid: str
    relevance: str


class AggregatedStatusCount(BaseModel):
    pending: Optional[int] = None
    failed: Optional[int] = None
    completed: Optional[int] = None
    cancelled: Optional[int] = None
    active: Optional[int] = None
    total: Optional[int] = None


class AggregatedMeetsCriteriaCount(BaseModel):
    abstract: AggregatedCount
    fulltext: AggregatedCount


class EvaluationResultItem(BaseModel):
    evaluation_id: str
    status: Optional[str] = None
    created_at: Optional[datetime] = None
    filter_hash: Optional[str] = None

    # --- Article metadata ---
    title: Optional[str] = None
    year: Optional[int] = None
    DOI: Optional[str] = None
    pii: Optional[str] = None
    sgrid: Optional[str] = None
    scopus_link: Optional[str] = None
    source_title: Optional[str] = None
    relevance: Optional[str] = None

    authors: Optional[List[ScopusAuthor]] = None
    keywords: Optional[List[str]] = None

    # --- Abstract evaluation ---
    meets_criteria: Optional[str] = None
    abstract_quotation: Optional[str] = None
    rationale: Optional[str] = None

    # --- Full-text evaluation ---
    full_text_meets_criteria: Optional[str] = None
    full_text_quotation: Optional[str] = None
    full_text_rationale: Optional[str] = None
    evidence_quotation_source: Optional[str] = None

    # --- Refined question ---
    has_refined_question: Optional[str] = None
    refined_question: Optional[str] = None

    # --- Prompts & raw model I/O ---
    prompt: Optional[str] = None
    raw_response: Optional[str] = None
    raw_full_text_prompt: Optional[str] = None
    raw_full_text_response: Optional[str] = None
    raw_refined_question_prompt: Optional[str] = None
    raw_refined_question_response: Optional[str] = None


class EvaluationHistoryBase(BaseModel):
    """Shared fields for evaluation history models."""

    # ---- Identity & metadata ----
    id: str
    status: str
    created_at: datetime
    user: Optional[str] = None
    group_id: Optional[str] = None

    # ---- Search context ----
    search_query: str
    search_type: SearchType
    starting_year: int

    source_types: List[SourceType]
    citation_types: List[CitationType]
    sd_documents_only: bool
    show_empty_abstracts: bool

    # ---- Criteria ----
    criteria: str
    criteria_prefix: str
    is_criteria_same_as_search_query: bool

    # ---- GPT config ----
    gpt_model: GptModel
    reasoning_effort: Optional[ReasoningEffort] = None
    verbosity: Optional[Verbosity] = None
    temperature: Optional[float] = None

    # ---- Evaluation config ----
    evaluation_types: Optional[List[EvaluationType]] = Field(default_factory=list)
    strict_abstract_evaluation_type: Optional[StrictAbstractEvaluationType] = None

    # ---- Prompts ----
    system_prompt: str

    initial_prompt: str
    final_prompt: str
    abstract_meets_criteria_prompt: str
    abstract_rationale_prompt: str

    abstract_initial_prompt_strict: str
    abstract_final_prompt_strict: str
    abstract_meets_criteria_prompt_strict: str
    abstract_rationale_prompt_strict: str
    abstract_quotation_prompt_strict: str

    has_refined_question_prompt: str
    refined_question_prompt: str
    refined_question_field_prompt: str

    full_text_initial_prompt: str
    full_text_final_prompt: str
    full_text_meets_criteria_prompt: str
    full_text_rationale_prompt: str
    full_text_quotation_prompt: str
    full_text_quotation_json_field_prompt: str

    # ---- Article selection ----
    selected_sgrids: List[str]
    sgrid_to_relevance_mappings: List[SgridRelevanceMapping]

    # ---- Aggregations ----
    aggregated_status_count: AggregatedStatusCount
    aggregated_meets_criteria_count: AggregatedMeetsCriteriaCount


class EvaluationHistory(EvaluationHistoryBase):
    """Full evaluation history with hydrated result objects."""

    # ---- Results ----
    evaluation_results: List[EvaluationResultItem]


class EvaluationHistoryApiResponse(EvaluationHistoryBase):
    """
    Lightweight evaluation history as returned by
    GET /api/evaluation/history/{evaluation_id}.
    Contains only result IDs in `evaluated_results`;
    full result data must be fetched via the batch endpoint.
    """

    # ---- Result IDs (not full objects) ----
    evaluated_results: List[str] = Field(default_factory=list)


class EvaluationResponse(BaseModel):
    id: str = Field(..., description="Evaluation history ID returned by the MOS Evaluation API")
    status: EvaluationStatus = Field(..., description="Current evaluation status (e.g., Active, Completed, Failed)")
    evaluation: Optional[EvaluationHistory] = Field(None,description="List of evaluation result objects when status is 'Completed'")
