from enum import Enum


class SearchType(str, Enum):
    VECTOR_SEARCH = "vector"
    ELASTIC_SEARCH = "elastic"
    CITATION_SEARCH = "citation"
    EIDS_SEARCH = "eids"
    DEEP_SEARCH = "deep_search"


class SourceType(str, Enum):
    BOOK = 'b'
    TRADE_JOURNAL = 'd'
    JOURNAL = 'j'
    BOOK_SERIES = 'k'
    MULTI_VOLUME_REFERENCE_WORKS = 'm'
    CONFERENCE_PROCEEDING = 'p'
    REPORT = 'r'
    PRE_PRINT = 'x'
    UNKNOWN = ''


ALL_SOURCE_TYPES = [s.value for s in SourceType]


class CitationType(str, Enum):
    REVIEW = 're'
    ARTICLE = 'ar'
    BOOK = 'bk'
    BOOK_REVIEW = 'br'
    BUSINESS_ARTICLE = 'bz'
    CHAPTER = 'ch'
    CONFERENCE_PAPER = 'cp'
    CONFERENCE_REVIEW = 'cr'
    DISSERTATION = 'di'
    DATA_PAPER = 'dp'
    EDITORIAL = 'ed'
    ERRATUM = 'er'
    ARTICLE_IN_PRESS = 'ip'
    LETTER = 'le'
    NOTE = 'no'
    PATENT = 'pa'
    PREPRINT = 'pp'
    PRESS_RELEASE = 'pr'
    REPORT = 'rp'
    SHORT_SURVEY = 'sh'
    WORKING_PAPER = 'wp'
    TOMBSTONE = 'tb'
    UNKNOWN = ''


ALL_CITATION_TYPES = [c.value for c in CitationType]


class ReasoningEffort(str, Enum):
    none = "none"
    minimal = "minimal"
    low = "low"
    medium = "medium"
    high = "high"
    xhigh = "xhigh"


class Verbosity(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"


class GptModel(str, Enum):
    gpt_5 = "gpt-5"
    gpt_5_mini = "gpt-5-mini"
    gpt_5_nano = "gpt-5-nano"
    gpt_5_1 = "gpt-5.1"
    gpt_5_2 = "gpt-5.2"
    gpt_5_4 = "gpt-5.4"
    gpt_5_4_pro = "gpt-5.4-pro"
    gpt_5_5 = "gpt-5.5"

    gpt_4o = "gpt_4o"
    gpt_4o_mini = "gpt_4o_mini"

    gpt_4_1 = "gpt_4.1"
    gpt_4_1_mini = "gpt_4.1_mini"

    o3_mini = "o3-mini"
    o4_mini = "o4-mini"


class EvaluationType(str, Enum):
    REFINED_QUESTION = "refined_question"
    FULL_TEXT = "full_text"


class StrictAbstractEvaluationType(str, Enum):
    NO_ARTICLES = "no_articles"
    ALL_ARTICLES = "all_articles"
    ARTICLES_WITHOUT_FULL_TEXT = "articles_without_full_text"


class DefaultPromptCategory(str, Enum):
    EVALUATION = "evaluation"
    ES_SEARCH_QUERY = "es-search-query"
    EXTRACT_CRITERIA = "extract-criteria"
    DEEP_SEARCH = "deep-search"


class ExtractCriteriaPromptType(str, Enum):
    DEFAULT = "default"
    SYSTEMATIC_REVIEW = "systematic_review"


class EvaluationStatus(str, Enum):
    PENDING = "Pending"
    FAILED = "Failed"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled"
    ACTIVE = "Active"


class ExpansionLevel(str, Enum):
    CONSERVATIVE = "conservative"
    BALANCED = "balanced"
    AGGRESSIVE = "aggressive"
